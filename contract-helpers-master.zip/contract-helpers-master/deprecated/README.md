# Deprecated packages

Archive of deprecated packages:

- **[ABIs](./abis)**: Aragon-related ABIs
- **[Migrations](./migrations)**: Truffle migration file
- **[Truffle v4 config](./truffle-config-v4)**: Base Truffle v4 configuration for Aragon smart contract development
