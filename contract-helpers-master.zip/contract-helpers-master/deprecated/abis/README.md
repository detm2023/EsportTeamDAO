# Aragon-related ABIs

[![Status](https://img.shields.io/badge/stability-deprecated-lightgrey.svg?style=flat-square)](https://nodejs.org/api/documentation.html#documentation_stability_index)
[![npm version](https://img.shields.io/npm/v/@aragon/abis.svg?style=flat-square&color=lightgrey)](https://npmjs.org/package/@aragon/abis)

> **⚠️  Deprecation notice**: this package has been deprecated and should not be used any more. Aragon-related contract packages have been pruned to reduce their install weight and to only contain the necessary Solidity files and compiled ABIs.

Collection of Aragon-related ABI files, with no extra dependencies (for faster install time!).
