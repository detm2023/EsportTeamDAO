# Truffle Migrations

[![Status](https://img.shields.io/badge/stability-deprecated-lightgrey.svg?style=flat-square)](https://nodejs.org/api/documentation.html#documentation_stability_index)
[![npm version](https://img.shields.io/npm/v/@aragon/contract-helpers-migrations.svg?style=flat-square&color=lightgrey)](https://npmjs.org/package/@aragon/contract-helpers-migrations)

> **⚠️  Deprecation notice**: this package has been deprecated and should not be used any more. For smart contract development, we recommend migrating to [buidler](https://buidler.dev/), which obviates the need for the `Migrations.sol` file.

See [Truffle migrations](https://truffleframework.com/docs/truffle/getting-started/running-migrations).
