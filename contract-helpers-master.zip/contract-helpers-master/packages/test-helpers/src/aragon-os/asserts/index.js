const assertRole = require('./assertRole')

module.exports = {
  ...assertRole,
}
