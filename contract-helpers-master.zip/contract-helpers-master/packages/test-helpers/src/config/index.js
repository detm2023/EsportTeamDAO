const artifacts = require('./artifacts')
const web3 = require('./web3')

module.exports = {
  ...artifacts,
  ...web3,
}
